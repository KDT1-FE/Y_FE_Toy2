export const SERVER_URL = import.meta.env.VITE_SERVER_URL;
export const CONTENT_TYPE = 'application/json';
export const SERVER_ID = import.meta.env.VITE_SERVER_ID;
