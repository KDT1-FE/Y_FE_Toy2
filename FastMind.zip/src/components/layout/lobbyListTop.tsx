import { Select } from '@chakra-ui/react';
import { useState } from 'react';
const LobbyListTop = () => {
  const [sortOption, setSortOption] = useState('');
  const [selectOption, setSelectOption] = useState('');
  return (
    <Select
      placeholder={selectOption}
      width={260}
      height="40px"
      backgroundColor={'white'}
      borderColor={'gray.200'}
      fontSize={16}>
      <option value="option1">모든 게임방 보기</option>
      <option value="option2">참여 가능한 게임방 보기</option>
    </Select>
  );
};

export default LobbyListTop;
